import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { ChevronLeft, Volume2, VolumeX, ExternalLink, Copy, Check, Globe, FileText, Image, Video } from 'lucide-react';
import { TypeAnimation } from 'react-type-animation';

const QRContentViewer: React.FC = () => {
  const [searchParams] = useSearchParams();
  const qrCode = searchParams.get('code') || '';
  const [speaking, setSpeaking] = useState(false);
  const [speechSynthesis, setSpeechSynthesis] = useState<SpeechSynthesis | null>(null);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [copied, setCopied] = useState(false);
  const [contentType, setContentType] = useState<'text' | 'url' | 'image' | 'video' | 'unknown'>('unknown');
  const [isTyping, setIsTyping] = useState(true);
  const [showFullText, setShowFullText] = useState(false);

  useEffect(() => {
    setSpeechSynthesis(window.speechSynthesis);
    
    const loadVoices = () => {
      const availableVoices = window.speechSynthesis.getVoices();
      setVoices(availableVoices);
    };

    window.speechSynthesis.onvoiceschanged = loadVoices;
    loadVoices();

    // Determine content type
    if (isURL(qrCode)) {
      if (isImageURL(qrCode)) {
        setContentType('image');
      } else if (isVideoURL(qrCode)) {
        setContentType('video');
      } else {
        setContentType('url');
      }
    } else {
      setContentType('text');
    }

    return () => {
      if (speaking) {
        window.speechSynthesis.cancel();
      }
    };
  }, [qrCode]);

  const isURL = (text: string): boolean => {
    try {
      new URL(text);
      return true;
    } catch {
      return false;
    }
  };

  const isImageURL = (url: string): boolean => {
    return /\.(jpg|jpeg|png|gif|webp|svg)$/i.test(url);
  };

  const isVideoURL = (url: string): boolean => {
    return /\.(mp4|webm|ogg|mov|avi)$/i.test(url) || url.includes('youtube.com') || url.includes('vimeo.com');
  };

  const handleSpeak = () => {
    if (!speechSynthesis) return;

    if (speaking) {
      speechSynthesis.cancel();
      setSpeaking(false);
      return;
    }

    const textToSpeak = contentType === 'url' ? `This QR code contains a web link: ${qrCode}` : qrCode;
    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    
    // Try to find a female English voice
    const preferredVoice = voices.find(
      voice => voice.lang.includes('en') && voice.name.includes('Female')
    ) || voices[0];
    
    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }
    
    utterance.rate = 0.9;
    utterance.pitch = 1.1;
    
    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => setSpeaking(false);
    
    setSpeaking(true);
    speechSynthesis.speak(utterance);
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(qrCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const toggleTypingAnimation = () => {
    setIsTyping(!isTyping);
    setShowFullText(!isTyping);
  };

  const renderContentIcon = () => {
    switch (contentType) {
      case 'url':
        return <Globe className="h-8 w-8 text-blue-500" />;
      case 'image':
        return <Image className="h-8 w-8 text-green-500" />;
      case 'video':
        return <Video className="h-8 w-8 text-purple-500" />;
      default:
        return <FileText className="h-8 w-8 text-gray-500" />;
    }
  };

  const renderContent = () => {
    switch (contentType) {
      case 'image':
        return (
          <div className="space-y-4">
            <img 
              src={qrCode} 
              alt="QR Code Content" 
              className="max-w-full h-auto rounded-lg shadow-md mx-auto"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
                setContentType('url');
              }}
            />
            <p className="text-gray-600 text-center">Image from QR code</p>
          </div>
        );
      
      case 'video':
        return (
          <div className="space-y-4">
            <video 
              controls 
              className="w-full rounded-lg shadow-md"
              onError={() => setContentType('url')}
            >
              <source src={qrCode} type="video/mp4" />
              Your browser does not support the video tag.
            </video>
            <p className="text-gray-600 text-center">Video from QR code</p>
          </div>
        );
      
      case 'url':
        return (
          <div className="space-y-4">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center mb-2">
                <Globe className="h-5 w-5 text-blue-600 mr-2" />
                <span className="font-semibold text-blue-800">Web Link Detected</span>
              </div>
              <p className="text-blue-700 break-all">{qrCode}</p>
            </div>
            <a 
              href={qrCode} 
              target="_blank" 
              rel="noopener noreferrer"
              className="btn btn-primary w-full"
            >
              <ExternalLink className="h-5 w-5 mr-2" />
              Open Link in New Tab
            </a>
          </div>
        );
      
      default:
        return (
          <div className="prose prose-lg max-w-none">
            {showFullText ? (
              <div className="whitespace-pre-wrap leading-relaxed">
                {qrCode}
              </div>
            ) : (
              <div>
                <TypeAnimation
                  sequence={[
                    qrCode,
                    () => {
                      // Animation complete
                    },
                  ]}
                  wrapper="div"
                  cursor={true}
                  repeat={0}
                  style={{ whiteSpace: 'pre-wrap', lineHeight: '1.8' }}
                  speed={70}
                  deletionSpeed={99}
                  omitDeletionAnimation={true}
                />
              </div>
            )}
          </div>
        );
    }
  };

  return (
    <div className="page-container max-w-4xl mx-auto">
      <div className="mb-6 flex justify-between items-center">
        <Link 
          to="/scan" 
          className="text-primary-600 hover:text-primary-800 flex items-center"
        >
          <ChevronLeft className="h-5 w-5 mr-1" />
          Back to Scanner
        </Link>
        
        <div className="flex space-x-3">
          <button 
            onClick={handleSpeak}
            className={`btn ${speaking ? 'btn-accent' : 'btn-secondary'} !py-2 !px-4`}
          >
            {speaking ? (
              <>
                <VolumeX className="h-5 w-5 mr-2" />
                Stop Narration
              </>
            ) : (
              <>
                <Volume2 className="h-5 w-5 mr-2" />
                AI Narration
              </>
            )}
          </button>

          <button 
            onClick={copyToClipboard}
            className={`btn ${copied ? 'btn-accent' : 'btn-secondary'} !py-2 !px-4`}
          >
            {copied ? (
              <>
                <Check className="h-5 w-5 mr-2" />
                Copied!
              </>
            ) : (
              <>
                <Copy className="h-5 w-5 mr-2" />
                Copy
              </>
            )}
          </button>
        </div>
      </div>
      
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="bg-gradient-to-r from-primary-600 to-accent-500 text-white p-6 md:p-8">
          <div className="flex items-center mb-4">
            {renderContentIcon()}
            <div className="ml-4">
              <h1 className="font-heading text-2xl md:text-3xl font-bold">
                QR Code Content
              </h1>
              <p className="text-gray-200 capitalize">
                {contentType === 'unknown' ? 'Text Content' : contentType} • Scanned Content
              </p>
            </div>
          </div>
        </div>
        
        <div className="p-6 md:p-8">
          {renderContent()}
          
          {contentType === 'text' && (
            <div className="mt-8 flex justify-center">
              <button 
                onClick={toggleTypingAnimation}
                className="btn btn-secondary"
              >
                {isTyping ? 'Skip Animation' : 'Restart Animation'}
              </button>
            </div>
          )}

          {/* QR Code Info */}
          <div className="mt-8 pt-6 border-t border-gray-200">
            <h3 className="font-heading text-lg font-semibold mb-4">QR Code Information</h3>
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium text-gray-700">Content Type:</span>
                  <span className="ml-2 text-gray-600 capitalize">
                    {contentType === 'unknown' ? 'Text' : contentType}
                  </span>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Length:</span>
                  <span className="ml-2 text-gray-600">{qrCode.length} characters</span>
                </div>
                <div className="md:col-span-2">
                  <span className="font-medium text-gray-700">Raw Content:</span>
                  <div className="mt-1 p-2 bg-white rounded border text-xs font-mono break-all">
                    {qrCode}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QRContentViewer;