import React, { useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Clock, BookOpen, Volume2, Video, Play } from 'lucide-react';
import { useStory } from '../contexts/StoryContext';

const StoryDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { findStoryById, setCurrentStory, currentStory } = useStory();
  
  useEffect(() => {
    if (id) {
      const story = findStoryById(id);
      if (story) {
        setCurrentStory(story);
      } else {
        navigate('/scan', { replace: true });
      }
    }
  }, [id, findStoryById, setCurrentStory, navigate]);
  
  if (!currentStory) {
    return (
      <div className="page-container">
        <div className="text-center">Loading story details...</div>
      </div>
    );
  }
  
  return (
    <div className="page-container animate-fade-in">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <Link to="/library" className="text-primary-600 hover:text-primary-800 flex items-center">
            ← Back to Library
          </Link>
        </div>
        
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="md:flex">
            <div className="md:shrink-0 md:w-1/3">
              <img 
                src={currentStory.coverImage} 
                alt={currentStory.title}
                className="h-full w-full object-cover md:h-full" 
              />
            </div>
            
            <div className="p-6 md:p-8 md:w-2/3">
              <div className="mb-6">
                <h1 className="font-heading text-3xl font-bold text-primary-800 mb-2">
                  {currentStory.title}
                </h1>
                <p className="text-gray-600 italic mb-4">By {currentStory.author}</p>
                
                <div className="flex flex-wrap gap-3 mb-4">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800">
                    {currentStory.category}
                  </span>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-accent-100 text-accent-800">
                    {currentStory.ageGroup}
                  </span>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                    <Clock className="h-3 w-3 mr-1" />
                    {currentStory.readingTime} min read
                  </span>
                </div>
              </div>
              
              <div className="mb-8">
                <h2 className="font-heading text-xl font-semibold mb-2">Story Summary</h2>
                <p className="text-gray-700 leading-relaxed">
                  {currentStory.summary}
                </p>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <Link 
                  to={`/read/${currentStory.id}`}
                  className="btn btn-primary"
                >
                  <BookOpen className="h-5 w-5 mr-2" />
                  Read Story
                </Link>
                
                <Link 
                  to={`/read/${currentStory.id}?mode=listen`}
                  className="btn btn-secondary"
                >
                  <Volume2 className="h-5 w-5 mr-2" />
                  Listen
                </Link>
                
                <Link 
                  to={`/watch/${currentStory.id}`}
                  className="btn btn-accent"
                >
                  <Play className="h-5 w-5 mr-2" />
                  Watch
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StoryDetails;