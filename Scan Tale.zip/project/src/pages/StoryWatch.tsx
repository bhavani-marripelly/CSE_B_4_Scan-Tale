import React, { useEffect, useState, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ChevronLeft, Play, Pause, RotateCcw, Settings, Volume2, VolumeX, Video, BookOpen } from 'lucide-react';
import { TypeAnimation } from 'react-type-animation';
import { useStory } from '../contexts/StoryContext';
import StoryVideoPlayer from '../components/StoryVideoPlayer';

const StoryWatch: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { findStoryById } = useStory();
  const [story, setStory] = useState(findStoryById(id || ''));
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentScene, setCurrentScene] = useState(0);
  const [animationSpeed, setAnimationSpeed] = useState(50);
  const [autoPlay, setAutoPlay] = useState(true);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [speaking, setSpeaking] = useState(false);
  const [viewMode, setViewMode] = useState<'video' | 'text'>('video');
  const speechSynthesisRef = useRef<SpeechSynthesis | null>(null);
  const [showSettings, setShowSettings] = useState(false);

  useEffect(() => {
    if (id) {
      const foundStory = findStoryById(id);
      if (foundStory) {
        setStory(foundStory);
      }
    }
    
    speechSynthesisRef.current = window.speechSynthesis;
    
    if (story) {
      document.title = `Watching: ${story.title} | ScanTale`;
    }
    
    return () => {
      document.title = 'ScanTale - Interactive Reading Experience';
      if (speechSynthesisRef.current && speaking) {
        speechSynthesisRef.current.cancel();
      }
    };
  }, [id, findStoryById]);

  const scenes = story ? story.content.split('\n\n').filter(p => p.trim()) : [];

  const speakText = (text: string) => {
    if (!voiceEnabled || !speechSynthesisRef.current) return;
    
    speechSynthesisRef.current.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.8;
    utterance.pitch = 1.1;
    utterance.volume = 0.9;
    
    utterance.onstart = () => setSpeaking(true);
    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => setSpeaking(false);
    
    speechSynthesisRef.current.speak(utterance);
  };

  const handlePlay = () => {
    setIsPlaying(true);
    if (voiceEnabled && scenes[currentScene]) {
      speakText(scenes[currentScene]);
    }
  };

  const handlePause = () => {
    setIsPlaying(false);
    if (speechSynthesisRef.current) {
      speechSynthesisRef.current.cancel();
      setSpeaking(false);
    }
  };

  const handleRestart = () => {
    setCurrentScene(0);
    setIsPlaying(false);
    if (speechSynthesisRef.current) {
      speechSynthesisRef.current.cancel();
      setSpeaking(false);
    }
  };

  const handleSceneComplete = () => {
    if (currentScene < scenes.length - 1) {
      setTimeout(() => {
        setCurrentScene(prev => prev + 1);
        if (autoPlay && voiceEnabled) {
          speakText(scenes[currentScene + 1]);
        }
      }, 2000);
    } else {
      setIsPlaying(false);
      setSpeaking(false);
    }
  };

  const toggleVoice = () => {
    setVoiceEnabled(!voiceEnabled);
    if (speaking && speechSynthesisRef.current) {
      speechSynthesisRef.current.cancel();
      setSpeaking(false);
    }
  };

  if (!story) {
    return (
      <div className="page-container">
        <div className="text-center">Story not found</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-primary-900 to-gray-900">
      {/* Header Controls */}
      <div className="relative z-10 bg-black/20 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <Link 
            to={`/story/${story.id}`} 
            className="text-white hover:text-accent-400 flex items-center transition-colors"
          >
            <ChevronLeft className="h-5 w-5 mr-1" />
            Back to Story
          </Link>
          
          <div className="flex items-center space-x-4">
            {/* View Mode Toggle */}
            <div className="flex bg-black/30 rounded-lg p-1">
              <button
                onClick={() => setViewMode('video')}
                className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  viewMode === 'video'
                    ? 'bg-accent-500 text-white'
                    : 'text-gray-300 hover:text-white'
                }`}
              >
                <Video className="h-4 w-4 mr-2" />
                Video
              </button>
              <button
                onClick={() => setViewMode('text')}
                className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  viewMode === 'text'
                    ? 'bg-accent-500 text-white'
                    : 'text-gray-300 hover:text-white'
                }`}
              >
                <BookOpen className="h-4 w-4 mr-2" />
                Text
              </button>
            </div>
            
            <button
              onClick={toggleVoice}
              className={`p-2 rounded-lg transition-colors ${
                voiceEnabled ? 'bg-accent-500 text-white' : 'bg-gray-600 text-gray-300'
              }`}
              title={voiceEnabled ? 'Disable narration' : 'Enable narration'}
            >
              {voiceEnabled ? <Volume2 className="h-5 w-5" /> : <VolumeX className="h-5 w-5" />}
            </button>
            
            <button
              onClick={() => setShowSettings(!showSettings)}
              className="p-2 rounded-lg bg-gray-600 text-white hover:bg-gray-500 transition-colors"
            >
              <Settings className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Settings Panel */}
      {showSettings && (
        <div className="fixed top-20 right-4 bg-white rounded-lg shadow-xl p-6 z-20 w-80">
          <h3 className="font-heading text-lg font-semibold mb-4">Animation Settings</h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Animation Speed: {animationSpeed}ms
              </label>
              <input
                type="range"
                min="20"
                max="100"
                value={animationSpeed}
                onChange={(e) => setAnimationSpeed(Number(e.target.value))}
                className="w-full"
              />
            </div>
            
            <div className="flex items-center">
              <input
                type="checkbox"
                id="autoplay"
                checked={autoPlay}
                onChange={(e) => setAutoPlay(e.target.checked)}
                className="mr-2"
              />
              <label htmlFor="autoplay" className="text-sm text-gray-700">
                Auto-advance scenes
              </label>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="relative min-h-screen flex flex-col">
        {/* Background Image with Overlay (only for text mode) */}
        {viewMode === 'text' && (
          <div className="absolute inset-0">
            <img 
              src={story.coverImage} 
              alt={story.title}
              className="w-full h-full object-cover opacity-20"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-black/60"></div>
          </div>
        )}

        {/* Story Content */}
        <div className="relative z-10 flex-grow flex items-center justify-center px-4 py-8">
          <div className="max-w-6xl w-full">
            {/* Story Title */}
            <div className="text-center mb-8">
              <h1 className="font-heading text-4xl md:text-6xl font-bold text-white mb-4 drop-shadow-lg">
                {story.title}
              </h1>
              <p className="text-xl text-accent-300 italic drop-shadow">
                by {story.author}
              </p>
            </div>

            {/* Scene Display */}
            <div className={`${viewMode === 'text' ? 'bg-black/40 backdrop-blur-sm' : ''} rounded-2xl p-8 md:p-12 mb-8 min-h-[500px] flex items-center justify-center`}>
              {viewMode === 'video' ? (
                <div className="w-full h-[500px]">
                  <StoryVideoPlayer
                    story={story}
                    currentScene={currentScene}
                    isPlaying={isPlaying}
                    onSceneComplete={handleSceneComplete}
                    voiceEnabled={voiceEnabled}
                  />
                </div>
              ) : (
                <div className="text-center">
                  {isPlaying && scenes[currentScene] ? (
                    <div className="prose prose-xl prose-invert max-w-none">
                      <TypeAnimation
                        key={currentScene}
                        sequence={[
                          scenes[currentScene],
                          () => handleSceneComplete(),
                        ]}
                        wrapper="div"
                        cursor={true}
                        repeat={0}
                        style={{ 
                          whiteSpace: 'pre-wrap', 
                          lineHeight: '1.8',
                          fontSize: '1.25rem',
                          textAlign: 'center'
                        }}
                        speed={animationSpeed}
                        deletionSpeed={99}
                        omitDeletionAnimation={true}
                      />
                    </div>
                  ) : (
                    <div className="text-white/80 text-xl leading-relaxed">
                      {scenes[currentScene] || "Story complete!"}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Progress Indicator */}
            <div className="mb-6">
              <div className="flex justify-between text-white/60 text-sm mb-2">
                <span>Scene {currentScene + 1} of {scenes.length}</span>
                <span>{Math.round(((currentScene + 1) / scenes.length) * 100)}% complete</span>
              </div>
              <div className="w-full bg-white/20 rounded-full h-2">
                <div 
                  className="bg-gradient-to-r from-accent-400 to-accent-600 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${((currentScene + 1) / scenes.length) * 100}%` }}
                ></div>
              </div>
            </div>

            {/* Controls */}
            <div className="flex justify-center items-center space-x-6">
              <button
                onClick={handleRestart}
                className="p-3 bg-gray-600 hover:bg-gray-500 text-white rounded-full transition-colors"
                title="Restart story"
              >
                <RotateCcw className="h-6 w-6" />
              </button>

              <button
                onClick={isPlaying ? handlePause : handlePlay}
                className="p-4 bg-accent-500 hover:bg-accent-600 text-white rounded-full transition-colors shadow-lg"
                disabled={currentScene >= scenes.length}
              >
                {isPlaying ? (
                  <Pause className="h-8 w-8" />
                ) : (
                  <Play className="h-8 w-8 ml-1" />
                )}
              </button>

              <button
                onClick={() => {
                  if (currentScene < scenes.length - 1) {
                    setCurrentScene(prev => prev + 1);
                    if (voiceEnabled) {
                      speakText(scenes[currentScene + 1]);
                    }
                  }
                }}
                className="p-3 bg-primary-600 hover:bg-primary-500 text-white rounded-full transition-colors"
                disabled={currentScene >= scenes.length - 1}
                title="Next scene"
              >
                <ChevronLeft className="h-6 w-6 rotate-180" />
              </button>
            </div>

            {/* Voice Status */}
            {speaking && (
              <div className="flex justify-center mt-4">
                <div className="bg-accent-500/20 border border-accent-400/30 rounded-lg px-4 py-2 flex items-center">
                  <Volume2 className="h-4 w-4 text-accent-400 mr-2 animate-pulse" />
                  <span className="text-accent-300 text-sm">Narrating...</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Scene Navigation */}
        <div className="relative z-10 bg-black/20 backdrop-blur-sm p-4">
          <div className="max-w-6xl mx-auto">
            <div className="flex space-x-2 overflow-x-auto pb-2">
              {scenes.map((_, index) => (
                <button
                  key={index}
                  onClick={() => {
                    setCurrentScene(index);
                    if (voiceEnabled && !isPlaying) {
                      speakText(scenes[index]);
                    }
                  }}
                  className={`flex-shrink-0 w-12 h-12 rounded-lg flex items-center justify-center text-sm font-medium transition-colors ${
                    index === currentScene
                      ? 'bg-accent-500 text-white'
                      : index < currentScene
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-600 text-gray-300 hover:bg-gray-500'
                  }`}
                >
                  {index + 1}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StoryWatch;