import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, Search, BookOpen, Volume2, Play } from 'lucide-react';
import { useStory } from '../contexts/StoryContext';

const StoryLibrary: React.FC = () => {
  const { stories } = useStory();
  const [searchTerm, setSearchTerm] = React.useState('');
  const [selectedStory, setSelectedStory] = React.useState<any>(null);
  const [showStoryOptions, setShowStoryOptions] = React.useState(false);
  
  const filteredStories = stories.filter(story => 
    story.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    story.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
    story.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleStoryClick = (story: any) => {
    setSelectedStory(story);
    setShowStoryOptions(true);
  };

  const handleStoryOption = (option: 'read' | 'listen' | 'watch') => {
    if (!selectedStory) return;
    
    setShowStoryOptions(false);
    
    switch (option) {
      case 'read':
        window.location.href = `/read/${selectedStory.id}`;
        break;
      case 'listen':
        window.location.href = `/read/${selectedStory.id}?mode=listen`;
        break;
      case 'watch':
        window.location.href = `/watch/${selectedStory.id}`;
        break;
    }
  };

  const closeStoryOptions = () => {
    setShowStoryOptions(false);
    setSelectedStory(null);
  };
  
  return (
    <>
      <div className="page-container">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8">
            <h1 className="font-heading text-3xl font-bold text-primary-800 mb-4">
              Story Library
            </h1>
            <p className="text-gray-600 max-w-3xl">
              Browse our collection of interactive stories. Each story comes with reading, 
              listening, and watching options for a complete experience.
            </p>
          </div>
          
          <div className="relative mb-8">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search by title, author or category..."
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          {filteredStories.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredStories.map(story => (
                <div 
                  key={story.id} 
                  onClick={() => handleStoryClick(story)}
                  className="card group hover:translate-y-[-4px] cursor-pointer"
                >
                  <div className="relative h-48 overflow-hidden">
                    <img 
                      src={story.coverImage} 
                      alt={story.title}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-0 left-0 p-4 text-white">
                      <div className="flex flex-wrap gap-2">
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-primary-500 text-white">
                          {story.category}
                        </span>
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-700/80 text-white">
                          <Clock className="h-3 w-3 mr-1" />
                          {story.readingTime} min
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-4">
                    <h2 className="font-heading text-xl font-bold mb-1 text-primary-800 line-clamp-1">
                      {story.title}
                    </h2>
                    <p className="text-gray-600 text-sm mb-2">By {story.author}</p>
                    <p className="text-gray-700 text-sm line-clamp-2 mb-4">
                      {story.summary}
                    </p>
                    
                    {/* Quick Action Buttons */}
                    <div className="flex space-x-2">
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          handleStoryOption('read');
                        }}
                        className="flex-1 bg-primary-50 hover:bg-primary-100 text-primary-700 text-xs py-2 px-3 rounded-lg transition-colors flex items-center justify-center"
                      >
                        <BookOpen className="h-3 w-3 mr-1" />
                        Read
                      </button>
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          handleStoryOption('listen');
                        }}
                        className="flex-1 bg-accent-50 hover:bg-accent-100 text-accent-700 text-xs py-2 px-3 rounded-lg transition-colors flex items-center justify-center"
                      >
                        <Volume2 className="h-3 w-3 mr-1" />
                        Listen
                      </button>
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          handleStoryOption('watch');
                        }}
                        className="flex-1 bg-purple-50 hover:bg-purple-100 text-purple-700 text-xs py-2 px-3 rounded-lg transition-colors flex items-center justify-center"
                      >
                        <Play className="h-3 w-3 mr-1" />
                        Watch
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-gray-50 rounded-lg">
              <p className="text-gray-600">No stories found matching your search.</p>
            </div>
          )}
        </div>
      </div>

      {/* Story Options Modal */}
      {showStoryOptions && selectedStory && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="relative">
              <img 
                src={selectedStory.coverImage} 
                alt={selectedStory.title}
                className="w-full h-64 object-cover rounded-t-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent rounded-t-2xl"></div>
              <button
                onClick={closeStoryOptions}
                className="absolute top-4 right-4 bg-black/50 hover:bg-black/70 text-white rounded-full p-2 transition-colors"
              >
                <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
              <div className="absolute bottom-0 left-0 p-6 text-white">
                <h2 className="font-heading text-3xl font-bold mb-2">{selectedStory.title}</h2>
                <p className="text-gray-200 italic">By {selectedStory.author}</p>
              </div>
            </div>
            
            <div className="p-8">
              <div className="mb-6">
                <h3 className="font-heading text-2xl font-bold text-primary-800 mb-4">
                  Choose Your Experience
                </h3>
                <p className="text-gray-600 mb-4">
                  {selectedStory.summary}
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-primary-100 text-primary-800">
                    {selectedStory.category}
                  </span>
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-accent-100 text-accent-800">
                    {selectedStory.ageGroup}
                  </span>
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-gray-100 text-gray-800">
                    {selectedStory.readingTime} min
                  </span>
                </div>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <button
                  onClick={() => handleStoryOption('read')}
                  className="group bg-gradient-to-br from-primary-500 to-primary-700 text-white p-6 rounded-xl hover:from-primary-600 hover:to-primary-800 transition-all duration-300 hover:scale-105"
                >
                  <BookOpen className="h-8 w-8 mx-auto mb-3 group-hover:scale-110 transition-transform" />
                  <h4 className="font-heading text-lg font-bold mb-2">Read</h4>
                  <p className="text-sm opacity-90">Interactive text with beautiful animations</p>
                </button>
                
                <button
                  onClick={() => handleStoryOption('listen')}
                  className="group bg-gradient-to-br from-accent-500 to-accent-700 text-white p-6 rounded-xl hover:from-accent-600 hover:to-accent-800 transition-all duration-300 hover:scale-105"
                >
                  <Volume2 className="h-8 w-8 mx-auto mb-3 group-hover:scale-110 transition-transform" />
                  <h4 className="font-heading text-lg font-bold mb-2">Listen</h4>
                  <p className="text-sm opacity-90">AI narration with voice synthesis</p>
                </button>
                
                <button
                  onClick={() => handleStoryOption('watch')}
                  className="group bg-gradient-to-br from-purple-500 to-purple-700 text-white p-6 rounded-xl hover:from-purple-600 hover:to-purple-800 transition-all duration-300 hover:scale-105"
                >
                  <Play className="h-8 w-8 mx-auto mb-3 group-hover:scale-110 transition-transform" />
                  <h4 className="font-heading text-lg font-bold mb-2">Watch</h4>
                  <p className="text-sm opacity-90">Cinematic video animations</p>
                </button>
              </div>
              
              <div className="mt-6 text-center">
                <button
                  onClick={closeStoryOptions}
                  className="text-gray-500 hover:text-gray-700 text-sm"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default StoryLibrary;