import React from 'react';
import { useNavigate } from 'react-router-dom';
import { BookOpen, ArrowRight, Scan, Library, Volume2 } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const Welcome: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-primary-800 to-primary-900 text-white">
      <div className="flex-grow flex flex-col items-center justify-center px-4 text-center">
        <div className="animate-fade-in">
          <BookOpen className="h-24 w-24 mx-auto mb-6 text-accent-400" />
          
          <h1 className="font-heading text-4xl md:text-6xl font-bold mb-4">
            Welcome to ScanTale
            {user && (
              <span className="block text-2xl md:text-3xl text-accent-300 mt-2">
                {user.name}!
              </span>
            )}
          </h1>
          
          <p className="text-xl md:text-2xl max-w-2xl mx-auto mb-8 text-gray-200">
            Bring books to life with interactive stories, AI narration, and immersive experiences
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <button 
              onClick={() => navigate('/scan')}
              className="btn btn-accent text-lg group"
            >
              <Scan className="mr-2 h-5 w-5" />
              Start Scanning
              <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </button>
            
            <button 
              onClick={() => navigate('/library')}
              className="btn btn-secondary text-lg group bg-white/10 border-white/20 text-white hover:bg-white/20"
            >
              <Library className="mr-2 h-5 w-5" />
              Browse Library
            </button>
          </div>
        </div>
        
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-8 max-w-4xl w-full animate-slide-up">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 hover:bg-white/15 transition-colors">
            <Scan className="h-8 w-8 text-accent-400 mb-3" />
            <div className="text-accent-400 font-bold text-lg mb-2">Scan QR Codes</div>
            <p className="text-gray-200">Scan any book's QR code to unlock its interactive digital experience instantly</p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 hover:bg-white/15 transition-colors">
            <BookOpen className="h-8 w-8 text-accent-400 mb-3" />
            <div className="text-accent-400 font-bold text-lg mb-2">Interactive Reading</div>
            <p className="text-gray-200">Enjoy stories with beautiful typography, animations, and engaging visual effects</p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 hover:bg-white/15 transition-colors">
            <Volume2 className="h-8 w-8 text-accent-400 mb-3" />
            <div className="text-accent-400 font-bold text-lg mb-2">AI Narration & Video</div>
            <p className="text-gray-200">Listen to AI-powered narration or watch stories come to life with video animations</p>
          </div>
        </div>

        <div className="mt-12 text-center">
          <p className="text-gray-300 text-sm">
            Ready to transform your reading experience? Start by scanning a QR code or exploring our story library.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Welcome;