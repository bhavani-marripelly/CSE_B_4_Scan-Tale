import React, { useEffect, useState } from 'react';
import { useParams, Link, useSearchParams } from 'react-router-dom';
import { ChevronLeft, Video, Play } from 'lucide-react';
import { TypeAnimation } from 'react-type-animation';
import { useStory } from '../contexts/StoryContext';
import AIVoiceAssistant from '../components/AIVoiceAssistant';

const StoryReader: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const mode = searchParams.get('mode');
  const { findStoryById } = useStory();
  const [story, setStory] = useState(findStoryById(id || ''));
  const [animationComplete, setAnimationComplete] = useState(false);
  const [isTyping, setIsTyping] = useState(true);
  const [showFullText, setShowFullText] = useState(false);
  const [showVideo, setShowVideo] = useState(false);
  const [videoPlaying, setVideoPlaying] = useState(false);
  const videoRef = React.useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (id) {
      const foundStory = findStoryById(id);
      if (foundStory) {
        setStory(foundStory);
      }
    }
    
    if (story) {
      document.title = `Reading: ${story.title} | ScanTale`;
    }
    
    return () => {
      document.title = 'ScanTale - Interactive Reading Experience';
    };
  }, [id, findStoryById]);

  const handleVideoToggle = () => {
    if (!showVideo) {
      setShowVideo(true);
      setVideoPlaying(true);
      if (videoRef.current) {
        videoRef.current.play();
      }
    } else {
      setShowVideo(false);
      setVideoPlaying(false);
      if (videoRef.current) {
        videoRef.current.pause();
      }
    }
  };
  
  const toggleTypingAnimation = () => {
    setIsTyping(!isTyping);
    setShowFullText(!isTyping);
  };
  
  const paragraphs = story ? story.content.split('\n\n') : [];
  
  if (!story) {
    return (
      <div className="page-container">
        <div className="text-center">Story not found</div>
      </div>
    );
  }

  return (
    <div className="page-container max-w-4xl mx-auto">
      <div className="mb-6 flex justify-between items-center">
        <Link 
          to={`/story/${story.id}`} 
          className="text-primary-600 hover:text-primary-800 flex items-center"
        >
          <ChevronLeft className="h-5 w-5 mr-1" />
          Back to Story Details
        </Link>
        
        <div className="flex space-x-3">
          <AIVoiceAssistant text={story.content} autoPlay={mode === 'listen'} />
          
          {story.videoUrl && (
            <button 
              onClick={handleVideoToggle}
              className={`btn ${videoPlaying ? 'btn-accent' : 'btn-secondary'} !py-2 !px-4`}
            >
              <Video className="h-5 w-5 mr-2" />
              {showVideo ? 'Hide Story Animation' : 'Show Story Animation'}
            </button>
          )}

          <Link 
            to={`/watch/${story.id}`}
            className="btn btn-accent !py-2 !px-4"
          >
            <Play className="h-5 w-5 mr-2" />
            Watch Mode
          </Link>
        </div>
      </div>
      
      {showVideo && story.videoUrl && (
        <div className="mb-8 bg-black rounded-xl overflow-hidden shadow-lg relative">
          <video
            ref={videoRef}
            controls
            className="w-full aspect-video"
            poster={story.coverImage}
            onPlay={() => setVideoPlaying(true)}
            onPause={() => setVideoPlaying(false)}
            onEnded={() => {
              setVideoPlaying(false);
              setShowVideo(false);
            }}
          >
            <source src={story.videoUrl} type="video/mp4" />
            Your browser does not support the video tag.
          </video>
          <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-black/30 to-transparent"></div>
          <div className="absolute bottom-0 left-0 p-4 text-white">
            <h2 className="text-xl font-heading font-bold mb-2">{story.title}</h2>
            <p className="text-sm opacity-90">Visual story experience</p>
          </div>
        </div>
      )}
      
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="relative h-56 sm:h-72 md:h-96 overflow-hidden">
          <img 
            src={story.coverImage} 
            alt={story.title}
            className="w-full h-full object-cover" 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
          <div className="absolute bottom-0 left-0 p-6 md:p-8 text-white">
            <h1 className="font-heading text-3xl md:text-4xl font-bold mb-2">
              {story.title}
            </h1>
            <p className="text-gray-200 italic">By {story.author}</p>
          </div>
        </div>
        
        <div className="p-6 md:p-8">
          <div className="prose prose-lg max-w-none">
            {showFullText ? (
              <>
                {paragraphs.map((paragraph, index) => (
                  <p key={index} className="mb-4 leading-relaxed">
                    {paragraph}
                  </p>
                ))}
              </>
            ) : (
              <div>
                <TypeAnimation
                  sequence={[
                    story.content,
                    () => {
                      setAnimationComplete(true);
                    },
                  ]}
                  wrapper="div"
                  cursor={true}
                  repeat={0}
                  style={{ whiteSpace: 'pre-wrap', lineHeight: '1.8' }}
                  speed={70}
                  deletionSpeed={99}
                  omitDeletionAnimation={true}
                />
              </div>
            )}
          </div>
          
          <div className="mt-8 flex justify-center">
            <button 
              onClick={toggleTypingAnimation}
              className="btn btn-secondary"
            >
              {isTyping ? 'Skip Animation' : 'Restart Animation'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StoryReader;