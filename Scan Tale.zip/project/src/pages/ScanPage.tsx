import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Scan, AlertCircle, History, Camera, Settings, ExternalLink, Upload, Image as ImageIcon, X, Volume2, VolumeX, BookOpen, Play, Video } from 'lucide-react';
import { Html5Qrcode } from 'html5-qrcode';
import { useStory } from '../contexts/StoryContext';
import { formatDistanceToNow } from 'date-fns';

const ScanPage: React.FC = () => {
  const navigate = useNavigate();
  const { findStoryByQRCode, setCurrentStory, scannedCodes, addScannedCode } = useStory();
  const [scanning, setScanning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [processingImage, setProcessingImage] = useState(false);
  const [scanMode, setScanMode] = useState<'camera' | 'upload'>('camera');
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [speaking, setSpeaking] = useState(false);
  const [scannedStory, setScannedStory] = useState<any>(null);
  const [showStoryOptions, setShowStoryOptions] = useState(false);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const scannerContainerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const speechSynthesisRef = useRef<SpeechSynthesis | null>(null);
  
  useEffect(() => {
    speechSynthesisRef.current = window.speechSynthesis;
    
    // Welcome message when component loads
    if (voiceEnabled) {
      speakText("Welcome to ScanTale QR Scanner. You can scan QR codes using your camera or upload an image.");
    }
    
    return () => {
      if (speechSynthesisRef.current && speaking) {
        speechSynthesisRef.current.cancel();
      }
    };
  }, []);

  const speakText = (text: string) => {
    if (!voiceEnabled || !speechSynthesisRef.current) return;
    
    // Cancel any ongoing speech
    speechSynthesisRef.current.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.9;
    utterance.pitch = 1.1;
    utterance.volume = 0.8;
    
    utterance.onstart = () => setSpeaking(true);
    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => setSpeaking(false);
    
    speechSynthesisRef.current.speak(utterance);
  };

  const toggleVoice = () => {
    setVoiceEnabled(!voiceEnabled);
    if (speaking && speechSynthesisRef.current) {
      speechSynthesisRef.current.cancel();
      setSpeaking(false);
    }
    
    if (!voiceEnabled) {
      speakText("Voice narration enabled");
    }
  };
  
  const startScanner = async () => {
    if (!scannerContainerRef.current) return;
    
    try {
      setError(null);
      setScanning(true);
      
      if (voiceEnabled) {
        speakText("Starting camera scanner. Point your camera at a QR code.");
      }
      
      scannerRef.current = new Html5Qrcode('qr-reader');
      
      await scannerRef.current.start(
        { facingMode: 'environment' },
        {
          fps: 10,
          qrbox: { width: 250, height: 250 },
        },
        (decodedText) => {
          handleScanSuccess(decodedText);
        },
        (errorMessage) => {
          console.log(errorMessage);
        }
      );
    } catch (err) {
      setError('Camera access denied');
      setScanning(false);
      if (voiceEnabled) {
        speakText("Camera access denied. Please allow camera permissions and try again.");
      }
      console.error(err);
    }
  };
  
  const stopScanner = async () => {
    if (scannerRef.current && scannerRef.current.isScanning) {
      try {
        await scannerRef.current.stop();
        scannerRef.current = null;
        if (voiceEnabled) {
          speakText("Camera scanner stopped.");
        }
      } catch (err) {
        console.error(err);
      }
    }
    setScanning(false);
  };

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      const errorMsg = 'Please select a valid image file';
      setError(errorMsg);
      if (voiceEnabled) {
        speakText(errorMsg);
      }
      return;
    }

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      const errorMsg = 'Image file is too large. Please select an image under 10MB';
      setError(errorMsg);
      if (voiceEnabled) {
        speakText(errorMsg);
      }
      return;
    }

    setError(null);
    setProcessingImage(true);
    
    if (voiceEnabled) {
      speakText("Processing uploaded image. Scanning for QR code.");
    }

    try {
      // Create image URL for preview
      const imageUrl = URL.createObjectURL(file);
      setUploadedImage(imageUrl);

      // Scan QR code from the uploaded image
      const html5QrCode = new Html5Qrcode('qr-reader-upload');
      
      const result = await html5QrCode.scanFile(file, true);
      handleScanSuccess(result);
      
    } catch (err) {
      console.error('QR scan error:', err);
      const errorMsg = 'No QR code found in the uploaded image. Please try a different image or ensure the QR code is clearly visible.';
      setError(errorMsg);
      if (voiceEnabled) {
        speakText(errorMsg);
      }
    } finally {
      setProcessingImage(false);
    }
  };

  const clearUploadedImage = () => {
    if (uploadedImage) {
      URL.revokeObjectURL(uploadedImage);
      setUploadedImage(null);
    }
    setError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };
  
  const handleScanSuccess = (qrCode: string) => {
    stopScanner();
    clearUploadedImage();
    
    // Store the scanned QR code
    addScannedCode(qrCode);
    
    // Check if it's a story in our database
    const story = findStoryByQRCode(qrCode);
    
    if (story) {
      // If it's a known story, show story options
      setCurrentStory(story);
      setScannedStory(story);
      setShowStoryOptions(true);
      if (voiceEnabled) {
        speakText(`QR code scanned successfully! Found story: ${story.title} by ${story.author}. Choose how you want to experience this story.`);
      }
    } else {
      // For any other QR code, open in universal viewer
      if (voiceEnabled) {
        speakText("QR code scanned successfully! Opening content viewer.");
      }
      navigate(`/qr-content?code=${encodeURIComponent(qrCode)}`);
    }
  };

  const handleStoryOption = (option: 'read' | 'listen' | 'watch') => {
    if (!scannedStory) return;
    
    if (voiceEnabled) {
      const optionText = option === 'read' ? 'reading' : option === 'listen' ? 'listening to' : 'watching';
      speakText(`Starting ${optionText} experience for ${scannedStory.title}.`);
    }
    
    switch (option) {
      case 'read':
        navigate(`/read/${scannedStory.id}`);
        break;
      case 'listen':
        navigate(`/read/${scannedStory.id}?mode=listen`);
        break;
      case 'watch':
        navigate(`/watch/${scannedStory.id}`);
        break;
    }
  };

  const closeStoryOptions = () => {
    setShowStoryOptions(false);
    setScannedStory(null);
  };
  
  useEffect(() => {
    return () => {
      stopScanner();
      clearUploadedImage();
      if (speechSynthesisRef.current && speaking) {
        speechSynthesisRef.current.cancel();
      }
    };
  }, []);
  
  const navigateToTestStory = (storyId: string) => {
    if (voiceEnabled) {
      speakText("Opening test story options.");
    }
    const story = findStoryByQRCode(`test-story-${storyId}`);
    if (story) {
      setScannedStory(story);
      setShowStoryOptions(true);
    } else {
      // Fallback to direct navigation
      navigate(`/story/${storyId}`);
    }
  };

  const handleRecentScan = (scan: any) => {
    const story = findStoryByQRCode(scan.code);
    if (story) {
      setScannedStory(story);
      setShowStoryOptions(true);
      if (voiceEnabled) {
        speakText(`Opening previously scanned story: ${story.title}. Choose your experience.`);
      }
    } else {
      if (voiceEnabled) {
        speakText("Opening previously scanned content.");
      }
      navigate(`/qr-content?code=${encodeURIComponent(scan.code)}`);
    }
  };

  const handleScanModeChange = (mode: 'camera' | 'upload') => {
    setScanMode(mode);
    if (mode === 'camera') {
      clearUploadedImage();
      if (voiceEnabled) {
        speakText("Switched to camera scanning mode.");
      }
    } else {
      stopScanner();
      if (voiceEnabled) {
        speakText("Switched to image upload mode. You can now upload an image containing a QR code.");
      }
    }
    setError(null);
  };

  const renderCameraError = () => {
    if (!error?.toLowerCase().includes('camera access denied')) return null;

    return (
      <div className="bg-amber-50 border-l-4 border-amber-400 p-6 rounded-lg mb-6">
        <div className="flex items-start">
          <Camera className="h-6 w-6 text-amber-600 mr-4 mt-1" />
          <div>
            <h3 className="text-lg font-semibold text-amber-800 mb-2">Camera Access Required</h3>
            <p className="text-amber-700 mb-4">
              Please follow these steps to enable camera access:
            </p>
            <ol className="list-decimal list-inside space-y-2 text-amber-700">
              <li>Click the camera icon in your browser's address bar</li>
              <li>Select "Allow" for camera access</li>
              <li>Refresh this page</li>
            </ol>
            <div className="mt-4 flex items-center">
              <Settings className="h-4 w-4 text-amber-600 mr-2" />
              <span className="text-sm text-amber-600">
                Can't see the camera icon? Check your browser settings
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Story Options Modal
  if (showStoryOptions && scannedStory) {
    return (
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
          <div className="relative">
            <img 
              src={scannedStory.coverImage} 
              alt={scannedStory.title}
              className="w-full h-64 object-cover rounded-t-2xl"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent rounded-t-2xl"></div>
            <button
              onClick={closeStoryOptions}
              className="absolute top-4 right-4 bg-black/50 hover:bg-black/70 text-white rounded-full p-2 transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
            <div className="absolute bottom-0 left-0 p-6 text-white">
              <h2 className="font-heading text-3xl font-bold mb-2">{scannedStory.title}</h2>
              <p className="text-gray-200 italic">By {scannedStory.author}</p>
            </div>
          </div>
          
          <div className="p-8">
            <div className="mb-6">
              <h3 className="font-heading text-2xl font-bold text-primary-800 mb-4">
                Choose Your Experience
              </h3>
              <p className="text-gray-600 mb-4">
                {scannedStory.summary}
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-primary-100 text-primary-800">
                  {scannedStory.category}
                </span>
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-accent-100 text-accent-800">
                  {scannedStory.ageGroup}
                </span>
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-gray-100 text-gray-800">
                  {scannedStory.readingTime} min
                </span>
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <button
                onClick={() => handleStoryOption('read')}
                className="group bg-gradient-to-br from-primary-500 to-primary-700 text-white p-6 rounded-xl hover:from-primary-600 hover:to-primary-800 transition-all duration-300 hover:scale-105"
              >
                <BookOpen className="h-8 w-8 mx-auto mb-3 group-hover:scale-110 transition-transform" />
                <h4 className="font-heading text-lg font-bold mb-2">Read</h4>
                <p className="text-sm opacity-90">Interactive text with beautiful animations</p>
              </button>
              
              <button
                onClick={() => handleStoryOption('listen')}
                className="group bg-gradient-to-br from-accent-500 to-accent-700 text-white p-6 rounded-xl hover:from-accent-600 hover:to-accent-800 transition-all duration-300 hover:scale-105"
              >
                <Volume2 className="h-8 w-8 mx-auto mb-3 group-hover:scale-110 transition-transform" />
                <h4 className="font-heading text-lg font-bold mb-2">Listen</h4>
                <p className="text-sm opacity-90">AI narration with voice synthesis</p>
              </button>
              
              <button
                onClick={() => handleStoryOption('watch')}
                className="group bg-gradient-to-br from-purple-500 to-purple-700 text-white p-6 rounded-xl hover:from-purple-600 hover:to-purple-800 transition-all duration-300 hover:scale-105"
              >
                <Play className="h-8 w-8 mx-auto mb-3 group-hover:scale-110 transition-transform" />
                <h4 className="font-heading text-lg font-bold mb-2">Watch</h4>
                <p className="text-sm opacity-90">Cinematic video animations</p>
              </button>
            </div>
            
            <div className="mt-6 text-center">
              <button
                onClick={closeStoryOptions}
                className="text-gray-500 hover:text-gray-700 text-sm"
              >
                Scan another QR code
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="page-container">
      <div className="max-w-lg mx-auto">
        <div className="text-center mb-8">
          <div className="flex justify-between items-start mb-4">
            <div className="flex-1">
              <h1 className="font-heading text-3xl font-bold text-primary-800 mb-4">
                Universal QR Scanner
              </h1>
            </div>
            
            {/* Voice Control */}
            <button
              onClick={toggleVoice}
              className={`btn ${voiceEnabled ? 'btn-accent' : 'btn-secondary'} !py-2 !px-3 ml-4`}
              title={voiceEnabled ? 'Disable voice narration' : 'Enable voice narration'}
            >
              {voiceEnabled ? (
                <Volume2 className="h-5 w-5" />
              ) : (
                <VolumeX className="h-5 w-5" />
              )}
            </button>
          </div>
          
          <p className="text-gray-600 mb-6">
            Scan any QR code to unlock interactive content with voice narration and multimedia features
          </p>

          {/* Voice Status Indicator */}
          {speaking && (
            <div className="bg-accent-50 border border-accent-200 rounded-lg p-3 mb-4 flex items-center justify-center">
              <Volume2 className="h-4 w-4 text-accent-600 mr-2 animate-pulse" />
              <span className="text-accent-700 text-sm font-medium">Voice narration active</span>
            </div>
          )}

          {/* Scan Mode Toggle */}
          <div className="flex bg-gray-100 rounded-lg p-1 mb-6 max-w-sm mx-auto">
            <button
              onClick={() => handleScanModeChange('camera')}
              className={`flex-1 flex items-center justify-center py-2 px-4 rounded-md text-sm font-medium transition-colors ${
                scanMode === 'camera'
                  ? 'bg-white text-primary-700 shadow-sm'
                  : 'text-gray-600 hover:text-primary-600'
              }`}
            >
              <Camera className="h-4 w-4 mr-2" />
              Camera
            </button>
            <button
              onClick={() => handleScanModeChange('upload')}
              className={`flex-1 flex items-center justify-center py-2 px-4 rounded-md text-sm font-medium transition-colors ${
                scanMode === 'upload'
                  ? 'bg-white text-primary-700 shadow-sm'
                  : 'text-gray-600 hover:text-primary-600'
              }`}
            >
              <Upload className="h-4 w-4 mr-2" />
              Upload
            </button>
          </div>
          
          {renderCameraError()}
          
          <div 
            ref={scannerContainerRef}
            className="bg-white p-4 rounded-xl shadow-md mb-6"
          >
            <div className="relative">
              {scanMode === 'camera' ? (
                <>
                  <div id="qr-reader" style={{width: '100%'}}></div>
                  
                  {!scanning && (
                    <div className="absolute inset-0 bg-white border-2 border-dashed border-gray-300 rounded-lg p-8 flex flex-col items-center">
                      <Scan className="h-16 w-16 text-primary-300 mb-4" />
                      <p className="text-gray-500 mb-4">
                        Camera access required to scan QR codes
                      </p>
                      <button 
                        onClick={startScanner}
                        className="btn btn-primary"
                      >
                        Start Camera Scanning
                      </button>
                    </div>
                  )}
                  
                  {scanning && (
                    <div className="mt-4 space-y-3">
                      <div className="bg-green-50 border border-green-200 rounded-lg p-3 flex items-center justify-center">
                        <div className="animate-pulse h-2 w-2 bg-green-500 rounded-full mr-2"></div>
                        <span className="text-green-700 text-sm font-medium">Camera active - Point at QR code</span>
                      </div>
                      <button 
                        onClick={stopScanner}
                        className="btn btn-secondary w-full"
                      >
                        Stop Camera
                      </button>
                    </div>
                  )}
                </>
              ) : (
                <>
                  <div id="qr-reader-upload" style={{display: 'none'}}></div>
                  
                  {!uploadedImage ? (
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                      <ImageIcon className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                      <p className="text-gray-500 mb-4">
                        Upload an image containing a QR code
                      </p>
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                        id="image-upload"
                      />
                      <label
                        htmlFor="image-upload"
                        className="btn btn-primary cursor-pointer"
                        onClick={() => {
                          if (voiceEnabled) {
                            speakText("Opening file picker. Please select an image containing a QR code.");
                          }
                        }}
                      >
                        <Upload className="h-5 w-5 mr-2" />
                        Choose Image
                      </label>
                      <p className="text-xs text-gray-400 mt-2">
                        Supports JPG, PNG, GIF (max 10MB)
                      </p>
                    </div>
                  ) : (
                    <div className="relative">
                      <img
                        src={uploadedImage}
                        alt="Uploaded QR code"
                        className="w-full max-h-64 object-contain rounded-lg"
                      />
                      <button
                        onClick={() => {
                          clearUploadedImage();
                          if (voiceEnabled) {
                            speakText("Image cleared. You can upload a new image.");
                          }
                        }}
                        className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 transition-colors"
                      >
                        <X className="h-4 w-4" />
                      </button>
                      {processingImage && (
                        <div className="absolute inset-0 bg-black/50 rounded-lg flex items-center justify-center">
                          <div className="bg-white rounded-lg p-4 flex items-center">
                            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary-600 mr-3"></div>
                            <span className="text-gray-700">Scanning QR code...</span>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
          
          {error && !error.toLowerCase().includes('camera access denied') && (
            <div className="bg-red-50 text-red-800 p-4 rounded-lg flex items-start mb-6">
              <AlertCircle className="h-5 w-5 mr-2 flex-shrink-0 mt-0.5" />
              <div className="text-left">{error}</div>
            </div>
          )}

          {/* Recently Scanned Codes */}
          {scannedCodes.length > 0 && (
            <div className="mt-8 bg-white rounded-xl shadow-md p-6">
              <h2 className="font-heading text-xl font-semibold mb-4 flex items-center">
                <History className="h-5 w-5 mr-2 text-primary-600" />
                Recently Scanned
              </h2>
              <div className="space-y-4">
                {scannedCodes.slice(0, 5).map((scan, index) => (
                  <div key={index} className="flex items-center justify-between text-sm">
                    <div className="flex-1">
                      <div className="font-medium text-gray-900 truncate">{scan.code}</div>
                      <div className="text-gray-500">
                        {formatDistanceToNow(scan.timestamp, { addSuffix: true })}
                      </div>
                    </div>
                    <button
                      onClick={() => handleRecentScan(scan)}
                      className="text-primary-600 hover:text-primary-800 flex items-center"
                    >
                      <ExternalLink className="h-4 w-4 mr-1" />
                      Open
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* For testing - direct story access */}
          <div className="mt-8 border-t border-gray-200 pt-6">
            <h2 className="font-heading text-xl font-semibold mb-4">Testing Options</h2>
            <p className="text-sm text-gray-500 mb-4">
              Don't have a QR code? Use these test stories:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <button 
                onClick={() => navigateToTestStory('1')}
                className="btn btn-secondary text-sm"
              >
                The Enchanted Forest
              </button>
              <button 
                onClick={() => navigateToTestStory('2')}
                className="btn btn-secondary text-sm"
              >
                Captain Whiskers
              </button>
              <button 
                onClick={() => navigateToTestStory('3')}
                className="btn btn-secondary text-sm"
              >
                The Little Robot
              </button>
              <button 
                onClick={() => navigateToTestStory('4')}
                className="btn btn-secondary text-sm"
              >
                The Dancing Dragon
              </button>
              <button 
                onClick={() => navigateToTestStory('5')}
                className="btn btn-secondary text-sm"
              >
                Time-Traveling Telescope
              </button>
              <button 
                onClick={() => navigateToTestStory('6')}
                className="btn btn-secondary text-sm"
              >
                Monkey and Crocodile
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScanPage;