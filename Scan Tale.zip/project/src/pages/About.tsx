import React from 'react';
import { BookOpen, Scan, Volume2, Video, Users, Award } from 'lucide-react';
import PublicNavbar from '../components/PublicNavbar';
import Footer from '../components/Footer';

const About: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <PublicNavbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-primary-800 to-primary-900 text-white py-20">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 text-center">
            <h1 className="font-heading text-4xl md:text-6xl font-bold mb-6">
              About ScanTale
            </h1>
            <p className="text-xl md:text-2xl max-w-3xl mx-auto text-gray-200">
              Revolutionizing the way we experience stories through interactive technology
            </p>
          </div>
        </section>

        {/* Mission Section */}
        <section className="py-16 bg-white">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="font-heading text-3xl font-bold text-primary-800 mb-4">
                Our Mission
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                We believe that stories have the power to transform lives. ScanTale bridges the gap between 
                traditional reading and digital innovation, creating immersive experiences that make literature 
                more accessible and engaging for everyone.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="bg-primary-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <BookOpen className="h-8 w-8 text-primary-600" />
                </div>
                <h3 className="font-heading text-xl font-semibold mb-2">Interactive Reading</h3>
                <p className="text-gray-600">
                  Transform static text into dynamic, engaging experiences with animations and multimedia content.
                </p>
              </div>

              <div className="text-center">
                <div className="bg-accent-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-accent-600" />
                </div>
                <h3 className="font-heading text-xl font-semibold mb-2">Accessibility</h3>
                <p className="text-gray-600">
                  Making literature accessible to all learning styles through visual, auditory, and interactive elements.
                </p>
              </div>

              <div className="text-center">
                <div className="bg-primary-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <Award className="h-8 w-8 text-primary-600" />
                </div>
                <h3 className="font-heading text-xl font-semibold mb-2">Innovation</h3>
                <p className="text-gray-600">
                  Pioneering the future of storytelling through cutting-edge technology and creative design.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="font-heading text-3xl font-bold text-primary-800 mb-4">
                How ScanTale Works
              </h2>
              <p className="text-lg text-gray-600">
                Experience stories like never before with our innovative features
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="bg-white rounded-xl p-6 shadow-md">
                <Scan className="h-12 w-12 text-primary-600 mb-4" />
                <h3 className="font-heading text-lg font-semibold mb-2">QR Code Scanning</h3>
                <p className="text-gray-600 text-sm">
                  Simply scan any book's QR code to unlock its interactive digital experience instantly.
                </p>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-md">
                <BookOpen className="h-12 w-12 text-accent-600 mb-4" />
                <h3 className="font-heading text-lg font-semibold mb-2">Animated Reading</h3>
                <p className="text-gray-600 text-sm">
                  Watch stories unfold with beautiful typography animations and visual effects.
                </p>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-md">
                <Volume2 className="h-12 w-12 text-primary-600 mb-4" />
                <h3 className="font-heading text-lg font-semibold mb-2">AI Narration</h3>
                <p className="text-gray-600 text-sm">
                  Listen to stories with high-quality AI-powered voice narration in multiple languages.
                </p>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-md">
                <Video className="h-12 w-12 text-accent-600 mb-4" />
                <h3 className="font-heading text-lg font-semibold mb-2">Video Stories</h3>
                <p className="text-gray-600 text-sm">
                  Watch stories come to life with accompanying video animations and visual storytelling.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="py-16 bg-white">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-12">
              <h2 className="font-heading text-3xl font-bold text-primary-800 mb-4">
                Our Vision
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                We envision a world where every story is an adventure, where technology enhances rather than 
                replaces the magic of reading, and where literature is accessible to everyone regardless of 
                their learning style or abilities.
              </p>
            </div>

            <div className="bg-gradient-to-r from-primary-600 to-accent-500 rounded-2xl p-8 text-white text-center">
              <h3 className="font-heading text-2xl font-bold mb-4">
                Join the Reading Revolution
              </h3>
              <p className="text-lg mb-6 opacity-90">
                Be part of the future of storytelling. Experience literature in ways you never imagined possible.
              </p>
              <a 
                href="/login" 
                className="inline-flex items-center px-6 py-3 bg-white text-primary-600 font-semibold rounded-lg hover:bg-gray-100 transition-colors"
              >
                Get Started Today
              </a>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default About;