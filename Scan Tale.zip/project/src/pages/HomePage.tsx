import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Scan, Volume2, Video, ArrowRight, Play, Users, Award, Sparkles } from 'lucide-react';
import PublicNavbar from '../components/PublicNavbar';
import Footer from '../components/Footer';

const HomePage: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <PublicNavbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-br from-primary-800 via-primary-700 to-primary-900 text-white overflow-hidden">
          <div className="absolute inset-0 bg-black/20"></div>
          <div className="absolute inset-0">
            <div className="absolute top-20 left-10 w-72 h-72 bg-accent-400/10 rounded-full blur-3xl animate-pulse"></div>
            <div className="absolute bottom-20 right-10 w-96 h-96 bg-primary-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
          </div>
          
          <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 py-20 lg:py-32">
            <div className="text-center">
              <div className="flex justify-center mb-8">
                <div className="relative">
                  <BookOpen className="h-20 w-20 text-accent-400 animate-float" />
                  <Sparkles className="absolute -top-2 -right-2 h-8 w-8 text-accent-300 animate-sparkle" />
                </div>
              </div>
              
              <h1 className="font-heading text-5xl md:text-7xl font-bold mb-6 animate-fade-in-up">
                Welcome to{' '}
                <span className="bg-gradient-to-r from-accent-400 to-accent-600 bg-clip-text text-transparent">
                  ScanTale
                </span>
              </h1>
              
              <p className="text-xl md:text-2xl max-w-3xl mx-auto mb-8 text-gray-200 animate-fade-in-up delay-200">
                Transform your reading experience with interactive stories, AI narration, 
                and immersive video animations. Scan any QR code to unlock magical storytelling.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16 animate-fade-in-up delay-400">
                <Link 
                  to="/login" 
                  className="btn btn-accent text-lg group px-8 py-4"
                >
                  Get Started Free
                  <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </Link>
                
                <Link 
                  to="/about" 
                  className="btn btn-secondary text-lg group bg-white/10 border-white/20 text-white hover:bg-white/20 px-8 py-4"
                >
                  Learn More
                  <Play className="ml-2 h-5 w-5" />
                </Link>
              </div>

              {/* Feature Preview */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto animate-fade-in-up delay-600">
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 hover:bg-white/15 transition-all duration-300 hover:scale-105">
                  <Scan className="h-12 w-12 text-accent-400 mb-4 mx-auto" />
                  <h3 className="font-heading text-xl font-bold mb-2">Scan & Discover</h3>
                  <p className="text-gray-200">Scan QR codes or upload images to unlock interactive story experiences</p>
                </div>
                
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 hover:bg-white/15 transition-all duration-300 hover:scale-105">
                  <Volume2 className="h-12 w-12 text-accent-400 mb-4 mx-auto" />
                  <h3 className="font-heading text-xl font-bold mb-2">AI Narration</h3>
                  <p className="text-gray-200">Listen to stories with high-quality AI-powered voice narration</p>
                </div>
                
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 hover:bg-white/15 transition-all duration-300 hover:scale-105">
                  <Video className="h-12 w-12 text-accent-400 mb-4 mx-auto" />
                  <h3 className="font-heading text-xl font-bold mb-2">Video Stories</h3>
                  <p className="text-gray-200">Watch stories come alive with beautiful animations and visual effects</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="py-20 bg-white">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-16">
              <h2 className="font-heading text-4xl font-bold text-primary-800 mb-4">
                How ScanTale Works
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Experience stories like never before in just three simple steps
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              <div className="text-center group">
                <div className="relative mb-6">
                  <div className="w-20 h-20 bg-gradient-to-br from-primary-500 to-primary-700 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                    <span className="text-2xl font-bold text-white">1</span>
                  </div>
                  <Scan className="h-8 w-8 text-primary-600 mx-auto" />
                </div>
                <h3 className="font-heading text-xl font-bold mb-3">Scan QR Code</h3>
                <p className="text-gray-600">
                  Use your camera to scan any book's QR code or upload an image containing a QR code
                </p>
              </div>

              <div className="text-center group">
                <div className="relative mb-6">
                  <div className="w-20 h-20 bg-gradient-to-br from-accent-500 to-accent-700 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                    <span className="text-2xl font-bold text-white">2</span>
                  </div>
                  <BookOpen className="h-8 w-8 text-accent-600 mx-auto" />
                </div>
                <h3 className="font-heading text-xl font-bold mb-3">Choose Experience</h3>
                <p className="text-gray-600">
                  Select how you want to experience the story: Read with animations, Listen with AI narration, or Watch with video
                </p>
              </div>

              <div className="text-center group">
                <div className="relative mb-6">
                  <div className="w-20 h-20 bg-gradient-to-br from-primary-500 to-primary-700 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                    <span className="text-2xl font-bold text-white">3</span>
                  </div>
                  <Sparkles className="h-8 w-8 text-primary-600 mx-auto" />
                </div>
                <h3 className="font-heading text-xl font-bold mb-3">Enjoy the Magic</h3>
                <p className="text-gray-600">
                  Immerse yourself in interactive storytelling with beautiful visuals, sound, and animations
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 bg-gray-50">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-16">
              <h2 className="font-heading text-4xl font-bold text-primary-800 mb-4">
                Why Choose ScanTale?
              </h2>
              <p className="text-xl text-gray-600">
                Revolutionary features that transform how you experience stories
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-8">
                <div className="flex items-start space-x-4">
                  <div className="bg-primary-100 rounded-lg p-3">
                    <BookOpen className="h-6 w-6 text-primary-600" />
                  </div>
                  <div>
                    <h3 className="font-heading text-xl font-bold mb-2">Interactive Reading</h3>
                    <p className="text-gray-600">
                      Watch text come alive with beautiful typography animations and visual effects that enhance comprehension and engagement.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-accent-100 rounded-lg p-3">
                    <Volume2 className="h-6 w-6 text-accent-600" />
                  </div>
                  <div>
                    <h3 className="font-heading text-xl font-bold mb-2">AI-Powered Narration</h3>
                    <p className="text-gray-600">
                      Listen to stories with natural, expressive AI voices that bring characters and narratives to life with perfect pronunciation.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-primary-100 rounded-lg p-3">
                    <Video className="h-6 w-6 text-primary-600" />
                  </div>
                  <div>
                    <h3 className="font-heading text-xl font-bold mb-2">Cinematic Animations</h3>
                    <p className="text-gray-600">
                      Experience stories through dynamic video animations that adapt to each story's genre and mood for maximum immersion.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-accent-100 rounded-lg p-3">
                    <Users className="h-6 w-6 text-accent-600" />
                  </div>
                  <div>
                    <h3 className="font-heading text-xl font-bold mb-2">Universal Accessibility</h3>
                    <p className="text-gray-600">
                      Designed for all learning styles and abilities, making literature accessible to everyone regardless of reading level.
                    </p>
                  </div>
                </div>
              </div>

              <div className="relative">
                <div className="bg-gradient-to-br from-primary-600 to-accent-500 rounded-2xl p-8 text-white">
                  <div className="text-center">
                    <Award className="h-16 w-16 mx-auto mb-6 text-accent-200" />
                    <h3 className="font-heading text-2xl font-bold mb-4">
                      Award-Winning Technology
                    </h3>
                    <p className="text-lg mb-6 opacity-90">
                      ScanTale combines cutting-edge QR technology with AI narration and real-time animations to create the future of storytelling.
                    </p>
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div>
                        <div className="text-3xl font-bold text-accent-200">50+</div>
                        <div className="text-sm opacity-80">Interactive Stories</div>
                      </div>
                      <div>
                        <div className="text-3xl font-bold text-accent-200">10K+</div>
                        <div className="text-sm opacity-80">Happy Readers</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-r from-primary-600 to-accent-500">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
            <h2 className="font-heading text-4xl font-bold text-white mb-6">
              Ready to Transform Your Reading Experience?
            </h2>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              Join thousands of readers who have discovered the magic of interactive storytelling. 
              Start your journey today with ScanTale.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link 
                to="/login" 
                className="btn bg-white text-primary-600 hover:bg-gray-100 text-lg px-8 py-4 font-semibold"
              >
                Start Reading Now
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
              <Link 
                to="/about" 
                className="btn border-2 border-white text-white hover:bg-white hover:text-primary-600 text-lg px-8 py-4"
              >
                Learn More
              </Link>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default HomePage;