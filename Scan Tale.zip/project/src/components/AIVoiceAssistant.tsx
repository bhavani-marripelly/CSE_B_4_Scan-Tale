import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX } from 'lucide-react';

interface AIVoiceAssistantProps {
  text: string;
  autoPlay?: boolean;
}

const AIVoiceAssistant: React.FC<AIVoiceAssistantProps> = ({ text, autoPlay = false }) => {
  const [speaking, setSpeaking] = useState(false);
  const [speechSynthesis, setSpeechSynthesis] = useState<SpeechSynthesis | null>(null);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);

  useEffect(() => {
    setSpeechSynthesis(window.speechSynthesis);
    
    const loadVoices = () => {
      const availableVoices = window.speechSynthesis.getVoices();
      setVoices(availableVoices);
    };

    window.speechSynthesis.onvoiceschanged = loadVoices;
    loadVoices();

    return () => {
      if (speaking) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  useEffect(() => {
    if (autoPlay) {
      handleSpeak();
    }
  }, [text, autoPlay, voices]);

  const handleSpeak = () => {
    if (!speechSynthesis) return;

    if (speaking) {
      speechSynthesis.cancel();
      setSpeaking(false);
      return;
    }

    const utterance = new SpeechSynthesisUtterance(text);
    
    // Try to find a female English voice
    const preferredVoice = voices.find(
      voice => voice.lang.includes('en') && voice.name.includes('Female')
    ) || voices[0];
    
    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }
    
    utterance.rate = 0.9; // Slightly slower for better clarity
    utterance.pitch = 1.1; // Slightly higher pitch for a more engaging tone
    
    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => setSpeaking(false);
    
    setSpeaking(true);
    speechSynthesis.speak(utterance);
  };

  return (
    <button
      onClick={handleSpeak}
      className={`btn ${speaking ? 'btn-accent' : 'btn-secondary'} !py-2 !px-4`}
      aria-label={speaking ? 'Stop narration' : 'Start narration'}
    >
      {speaking ? (
        <>
          <VolumeX className="h-5 w-5 mr-2" />
          Stop Narration
        </>
      ) : (
        <>
          <Volume2 className="h-5 w-5 mr-2" />
          AI Narration
        </>
      )}
    </button>
  );
};

export default AIVoiceAssistant;