import React, { useRef, useEffect, useState } from 'react';
import { Play, Pause, Volume2, VolumeX, Maximize, Minimize } from 'lucide-react';

interface StoryVideoPlayerProps {
  story: {
    id: string;
    title: string;
    content: string;
    coverImage: string;
    category: string;
  };
  currentScene: number;
  isPlaying: boolean;
  onSceneComplete: () => void;
  voiceEnabled: boolean;
}

const StoryVideoPlayer: React.FC<StoryVideoPlayerProps> = ({
  story,
  currentScene,
  isPlaying,
  onSceneComplete,
  voiceEnabled
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [animationProgress, setAnimationProgress] = useState(0);
  
  const scenes = story.content.split('\n\n').filter(p => p.trim());
  const currentSceneText = scenes[currentScene] || '';

  // Animation configurations based on story category
  const getAnimationConfig = () => {
    switch (story.category.toLowerCase()) {
      case 'fantasy':
        return {
          backgroundColor: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          particleColor: '#ffd700',
          textColor: '#ffffff',
          effects: ['sparkles', 'floating']
        };
      case 'adventure':
        return {
          backgroundColor: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
          particleColor: '#ff6b6b',
          textColor: '#ffffff',
          effects: ['waves', 'movement']
        };
      case 'science fiction':
        return {
          backgroundColor: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
          particleColor: '#00ffff',
          textColor: '#ffffff',
          effects: ['digital', 'matrix']
        };
      case 'moral tales':
        return {
          backgroundColor: 'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
          particleColor: '#90ee90',
          textColor: '#2d5016',
          effects: ['nature', 'gentle']
        };
      default:
        return {
          backgroundColor: 'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)',
          particleColor: '#ff69b4',
          textColor: '#333333',
          effects: ['bubbles', 'soft']
        };
    }
  };

  const drawFrame = (ctx: CanvasRenderingContext2D, canvas: HTMLCanvasElement, progress: number) => {
    const config = getAnimationConfig();
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Create gradient background
    const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    
    // Parse gradient colors from config
    if (story.category.toLowerCase() === 'fantasy') {
      gradient.addColorStop(0, `rgba(102, 126, 234, ${0.8 + Math.sin(progress * 0.01) * 0.2})`);
      gradient.addColorStop(1, `rgba(118, 75, 162, ${0.8 + Math.cos(progress * 0.01) * 0.2})`);
    } else if (story.category.toLowerCase() === 'adventure') {
      gradient.addColorStop(0, `rgba(240, 147, 251, ${0.8 + Math.sin(progress * 0.02) * 0.2})`);
      gradient.addColorStop(1, `rgba(245, 87, 108, ${0.8 + Math.cos(progress * 0.02) * 0.2})`);
    } else if (story.category.toLowerCase() === 'science fiction') {
      gradient.addColorStop(0, `rgba(79, 172, 254, ${0.8 + Math.sin(progress * 0.03) * 0.2})`);
      gradient.addColorStop(1, `rgba(0, 242, 254, ${0.8 + Math.cos(progress * 0.03) * 0.2})`);
    } else {
      gradient.addColorStop(0, `rgba(168, 237, 234, ${0.8 + Math.sin(progress * 0.015) * 0.2})`);
      gradient.addColorStop(1, `rgba(254, 214, 227, ${0.8 + Math.cos(progress * 0.015) * 0.2})`);
    }
    
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Add animated particles based on story category
    drawParticles(ctx, canvas, progress, config);
    
    // Add story-specific visual elements
    drawStoryElements(ctx, canvas, progress, story.category);
  };

  const drawParticles = (ctx: CanvasRenderingContext2D, canvas: HTMLCanvasElement, progress: number, config: any) => {
    const particleCount = 50;
    
    for (let i = 0; i < particleCount; i++) {
      const x = (Math.sin(progress * 0.01 + i) * canvas.width * 0.3) + canvas.width * 0.5;
      const y = (Math.cos(progress * 0.008 + i * 0.5) * canvas.height * 0.3) + canvas.height * 0.5;
      const size = Math.sin(progress * 0.02 + i) * 3 + 2;
      const opacity = Math.sin(progress * 0.015 + i) * 0.5 + 0.5;
      
      ctx.save();
      ctx.globalAlpha = opacity;
      ctx.fillStyle = config.particleColor;
      ctx.beginPath();
      ctx.arc(x, y, size, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  };

  const drawStoryElements = (ctx: CanvasRenderingContext2D, canvas: HTMLCanvasElement, progress: number, category: string) => {
    switch (category.toLowerCase()) {
      case 'fantasy':
        drawMagicalElements(ctx, canvas, progress);
        break;
      case 'adventure':
        drawAdventureElements(ctx, canvas, progress);
        break;
      case 'science fiction':
        drawSciFiElements(ctx, canvas, progress);
        break;
      default:
        drawGenericElements(ctx, canvas, progress);
    }
  };

  const drawMagicalElements = (ctx: CanvasRenderingContext2D, canvas: HTMLCanvasElement, progress: number) => {
    // Draw magical sparkles
    for (let i = 0; i < 20; i++) {
      const x = Math.random() * canvas.width;
      const y = Math.random() * canvas.height;
      const rotation = progress * 0.02 + i;
      
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(rotation);
      ctx.strokeStyle = '#ffd700';
      ctx.lineWidth = 2;
      ctx.globalAlpha = Math.sin(progress * 0.01 + i) * 0.5 + 0.5;
      
      // Draw star shape
      ctx.beginPath();
      for (let j = 0; j < 5; j++) {
        const angle = (j * Math.PI * 2) / 5;
        const x1 = Math.cos(angle) * 10;
        const y1 = Math.sin(angle) * 10;
        const x2 = Math.cos(angle + Math.PI / 5) * 5;
        const y2 = Math.sin(angle + Math.PI / 5) * 5;
        
        if (j === 0) ctx.moveTo(x1, y1);
        else ctx.lineTo(x1, y1);
        ctx.lineTo(x2, y2);
      }
      ctx.closePath();
      ctx.stroke();
      ctx.restore();
    }
  };

  const drawAdventureElements = (ctx: CanvasRenderingContext2D, canvas: HTMLCanvasElement, progress: number) => {
    // Draw moving waves
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
    ctx.lineWidth = 3;
    
    for (let i = 0; i < 5; i++) {
      ctx.beginPath();
      for (let x = 0; x < canvas.width; x += 10) {
        const y = Math.sin((x + progress * 2 + i * 50) * 0.01) * 30 + canvas.height * 0.7 + i * 20;
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
  };

  const drawSciFiElements = (ctx: CanvasRenderingContext2D, canvas: HTMLCanvasElement, progress: number) => {
    // Draw digital grid
    ctx.strokeStyle = 'rgba(0, 255, 255, 0.2)';
    ctx.lineWidth = 1;
    
    const gridSize = 50;
    for (let x = 0; x < canvas.width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    
    for (let y = 0; y < canvas.height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }
    
    // Draw moving data streams
    for (let i = 0; i < 10; i++) {
      const x = (progress * 3 + i * 100) % (canvas.width + 100);
      const y = i * (canvas.height / 10);
      
      ctx.fillStyle = `rgba(0, 255, 255, ${Math.sin(progress * 0.02 + i) * 0.5 + 0.5})`;
      ctx.fillRect(x - 50, y, 40, 4);
    }
  };

  const drawGenericElements = (ctx: CanvasRenderingContext2D, canvas: HTMLCanvasElement, progress: number) => {
    // Draw floating bubbles
    for (let i = 0; i < 15; i++) {
      const x = Math.sin(progress * 0.005 + i) * canvas.width * 0.4 + canvas.width * 0.5;
      const y = (progress * 0.5 + i * 50) % (canvas.height + 100);
      const size = Math.sin(progress * 0.01 + i) * 20 + 15;
      
      ctx.save();
      ctx.globalAlpha = 0.3;
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(x, y, size, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
  };

  const animate = () => {
    if (!canvasRef.current || !isPlaying) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    setAnimationProgress(prev => prev + 1);
    drawFrame(ctx, canvas, animationProgress);
    
    // Check if scene should complete (after 8 seconds)
    if (animationProgress > 480) { // 60fps * 8 seconds
      setAnimationProgress(0);
      onSceneComplete();
      return;
    }
    
    animationRef.current = requestAnimationFrame(animate);
  };

  useEffect(() => {
    if (isPlaying) {
      setAnimationProgress(0);
      animate();
    } else {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    }
    
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isPlaying, currentScene]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const resizeCanvas = () => {
      const container = canvas.parentElement;
      if (container) {
        canvas.width = container.clientWidth;
        canvas.height = container.clientHeight;
      }
    };
    
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    
    return () => window.removeEventListener('resize', resizeCanvas);
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      canvasRef.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  return (
    <div className="relative w-full h-full bg-black rounded-lg overflow-hidden">
      <canvas
        ref={canvasRef}
        className="w-full h-full"
        style={{ minHeight: '400px' }}
      />
      
      {/* Text Overlay */}
      <div className="absolute inset-0 flex items-center justify-center p-8">
        <div className="text-center max-w-4xl">
          <div 
            className="text-2xl md:text-3xl font-medium leading-relaxed drop-shadow-lg"
            style={{ 
              color: getAnimationConfig().textColor,
              textShadow: '2px 2px 4px rgba(0,0,0,0.5)'
            }}
          >
            {currentSceneText}
          </div>
        </div>
      </div>
      
      {/* Controls Overlay */}
      <div className="absolute top-4 right-4 flex space-x-2">
        <button
          onClick={toggleFullscreen}
          className="p-2 bg-black/50 hover:bg-black/70 text-white rounded-lg transition-colors"
        >
          {isFullscreen ? <Minimize className="h-5 w-5" /> : <Maximize className="h-5 w-5" />}
        </button>
      </div>
      
      {/* Progress Bar */}
      <div className="absolute bottom-4 left-4 right-4">
        <div className="w-full bg-black/30 rounded-full h-2">
          <div 
            className="bg-gradient-to-r from-accent-400 to-accent-600 h-2 rounded-full transition-all duration-100"
            style={{ width: `${(animationProgress / 480) * 100}%` }}
          ></div>
        </div>
      </div>
    </div>
  );
};

export default StoryVideoPlayer;