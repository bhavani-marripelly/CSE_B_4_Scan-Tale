import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { BookOpen, LogIn } from 'lucide-react';

const PublicNavbar: React.FC = () => {
  const location = useLocation();
  
  return (
    <header className="bg-white/95 backdrop-blur-sm shadow-sm sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex justify-between items-center py-4">
          <Link to="/" className="flex items-center space-x-2">
            <BookOpen className="h-8 w-8 text-primary-700" />
            <span className="font-heading text-xl font-bold text-primary-800">ScanTale</span>
          </Link>
          
          <nav className="hidden md:flex space-x-8">
            <Link 
              to="/" 
              className={`text-sm font-medium transition-colors ${
                location.pathname === '/' 
                  ? 'text-primary-700' 
                  : 'text-gray-600 hover:text-primary-600'
              }`}
            >
              Home
            </Link>
            
            <Link 
              to="/about" 
              className={`text-sm font-medium transition-colors ${
                location.pathname === '/about' 
                  ? 'text-primary-700' 
                  : 'text-gray-600 hover:text-primary-600'
              }`}
            >
              About
            </Link>
            
            <Link 
              to="/contact" 
              className={`text-sm font-medium transition-colors ${
                location.pathname === '/contact' 
                  ? 'text-primary-700' 
                  : 'text-gray-600 hover:text-primary-600'
              }`}
            >
              Contact
            </Link>
          </nav>

          <div className="flex items-center space-x-4">
            <Link 
              to="/login" 
              className="btn btn-primary flex items-center"
            >
              <LogIn className="h-4 w-4 mr-2" />
              Get Started
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
};

export default PublicNavbar;