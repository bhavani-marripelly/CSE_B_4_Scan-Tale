import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { BookOpen, Scan, Library, LogOut, User } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const Navbar: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  
  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex justify-between items-center py-4">
          <Link to="/welcome" className="flex items-center space-x-2">
            <BookOpen className="h-8 w-8 text-primary-700" />
            <span className="font-heading text-xl font-bold text-primary-800">ScanTale</span>
          </Link>
          
          <div className="flex items-center space-x-4">
            <nav className="flex space-x-1 sm:space-x-4">
              <Link 
                to="/scan" 
                className={`px-3 py-2 rounded-md text-sm font-medium ${
                  location.pathname === '/scan' 
                    ? 'bg-primary-50 text-primary-700' 
                    : 'text-gray-600 hover:bg-gray-50 hover:text-primary-600'
                }`}
              >
                <span className="flex items-center space-x-1">
                  <Scan className="h-5 w-5" />
                  <span className="hidden sm:inline">Scan</span>
                </span>
              </Link>
              
              <Link 
                to="/library" 
                className={`px-3 py-2 rounded-md text-sm font-medium ${
                  location.pathname === '/library' 
                    ? 'bg-primary-50 text-primary-700' 
                    : 'text-gray-600 hover:bg-gray-50 hover:text-primary-600'
                }`}
              >
                <span className="flex items-center space-x-1">
                  <Library className="h-5 w-5" />
                  <span className="hidden sm:inline">Library</span>
                </span>
              </Link>
            </nav>

            {/* User Menu */}
            <div className="flex items-center space-x-3 border-l border-gray-200 pl-4">
              <div className="flex items-center space-x-2">
                <User className="h-5 w-5 text-gray-400" />
                <span className="text-sm text-gray-700 hidden sm:inline">
                  {user?.name || user?.email}
                </span>
              </div>
              
              <button
                onClick={handleLogout}
                className="flex items-center space-x-1 px-3 py-2 text-sm font-medium text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-md transition-colors"
              >
                <LogOut className="h-4 w-4" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;