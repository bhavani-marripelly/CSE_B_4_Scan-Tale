import React from 'react';
import { BookOpen, Github } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-primary-800 text-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex flex-col sm:flex-row justify-between items-center">
          <div className="flex items-center space-x-2 mb-4 sm:mb-0">
            <BookOpen className="h-6 w-6" />
            <span className="font-heading text-lg font-bold">ScanTale</span>
          </div>
          
          <div className="text-sm text-gray-300">
            &copy; {new Date().getFullYear()} ScanTale. All rights reserved.
          </div>
          
          <div className="flex space-x-4 mt-4 sm:mt-0">
            <a href="#" className="text-gray-300 hover:text-white transition-colors">
              <Github className="h-5 w-5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;