import { Story } from '../types/Story';

export const stories: Story[] = [
  {
    id: '1',
    title: 'The Enchanted Forest',
    author: 'Eliza Thornberry',
    coverImage: 'https://images.pexels.com/photos/1632790/pexels-photo-1632790.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    qrCode: 'enchanted-forest-123',
    summary: 'A magical journey through an ancient forest where trees whisper secrets and animals speak in riddles.',
    content: `Once upon a time, in a land not so far away, there was an enchanted forest. The trees were taller than skyscrapers, and their leaves shimmered like emeralds in the sunlight.

Little Emily, a curious girl with bright eyes and an even brighter mind, had heard tales of this magical place her entire life. One day, she decided to see it for herself.

As she stepped into the forest, the trees seemed to bend toward her, as if whispering hello. "Welcome," a voice said, startling Emily. She looked around but saw no one.

"Down here," the voice continued. Emily looked down to see a small rabbit with unusually intelligent eyes. "My name is Thimble," the rabbit said. "And you must be the human child we've been expecting."

Emily couldn't believe her ears. A talking rabbit! "Expected? By whom?" she asked, kneeling down to get a better look at the extraordinary creature.

"By the forest, of course," Thimble replied. "The Ancient Oak has prophesied your arrival for centuries. You are the one who will help us save our home."

And so began Emily's adventure in the enchanted forest, where she would learn about courage, friendship, and the importance of protecting nature's magic.`,
    audioUrl: 'https://example.com/audio/enchanted-forest.mp3',
    videoUrl: 'https://player.vimeo.com/external/517090081.hd.mp4?s=50861b4b0609ffe4db54f66c63e1130da7bbe8b1&profile_id=175',
    ageGroup: '5-8 years',
    category: 'Fantasy',
    readingTime: 5
  },
  {
    id: '2',
    title: 'Captain Whiskers and the Lost Treasure',
    author: 'Samuel Pawprint',
    coverImage: 'https://images.pexels.com/photos/3278215/pexels-photo-3278215.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    qrCode: 'captain-whiskers-456',
    summary: 'Join Captain Whiskers, the bravest cat pirate on the seven seas, as he searches for the legendary Golden Mouse treasure.',
    content: `"Land ho!" shouted First Mate Fluffy from the crow's nest of The Whisker's Revenge.

Captain Whiskers, the most feared feline pirate of the Seven Seas, peered through his spyglass at the mysterious island on the horizon. His whiskers twitched with excitement.

"According to this map," he meowed, unrolling an ancient parchment on the ship's deck, "the Golden Mouse treasure is hidden somewhere on that island."

The crew of cats cheered, their tails swishing in anticipation. For years, they had searched for this legendary treasure, said to contain endless supplies of tuna and catnip.

As they anchored near the beach, Captain Whiskers adjusted his eye patch and pointed his paw toward the dense jungle. "Remember, crew, stay alert! The dogs of the Royal Navy might be lurking nearby."

With cautious steps and occasional naps (they were cats, after all), the feline pirates ventured into the heart of the island. They crossed rickety bridges, climbed tall trees, and even had to swim across a small stream (much to their dismay).

Finally, they reached a cave marked with a paw print symbol. "This is it!" Captain Whiskers declared. "The Golden Mouse awaits!"

But what they found inside wasn't what they expected, and their adventure was only just beginning...`,
    audioUrl: 'https://example.com/audio/captain-whiskers.mp3',
    videoUrl: 'https://player.vimeo.com/external/477721941.hd.mp4?s=1e39f156a06c4f4561a2ee4e8d443d54447b4549&profile_id=175',
    ageGroup: '6-10 years',
    category: 'Adventure',
    readingTime: 8
  },
  {
    id: '3',
    title: 'The Little Robot That Could',
    author: 'Dr. Cogsworth',
    coverImage: 'https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    qrCode: 'little-robot-789',
    summary: 'A heartwarming tale about a small, outdated robot who proves that determination and kindness are more important than having the latest technology.',
    content: `In the gleaming city of Mechanopolis, where robots of all shapes and sizes lived and worked, there was one little robot who stood out from the rest. Not because he was the shiniest or the smartest, but because he was the oldest.

B33P was a small, square robot with dented panels and outdated circuits. While newer robots could fly, transform, or process information at lightning speeds, B33P could only roll on his squeaky wheels and perform simple tasks.

One day, a great storm hit Mechanopolis, knocking out the central power grid. The advanced robots, dependent on wireless charging, quickly ran out of energy and shut down.

But not B33P. His old-fashioned battery system still worked, and he found himself the only functioning robot in the city.

"I must help," he beeped to himself, rolling slowly toward the central power station. The journey was difficult. He had to navigate fallen debris and climb steep inclines that made his motors whir in protest.

Many times, he thought of giving up. "I'm too old, too slow," he would beep sadly. But then he would remember all the robots who needed help, and he would continue on.

Through determination and clever problem-solving, B33P finally reached the power station. Using his simple tools, he managed to restart the system that the more complex robots couldn't fix.

As power returned to Mechanopolis and the other robots reactivated, they gathered around B33P with newfound respect. They realized that sometimes, being simple and reliable was more valuable than being the newest model.

From that day forward, B33P was no longer seen as outdated but was celebrated as the little robot that could—and did—save the city.`,
    audioUrl: 'https://example.com/audio/little-robot.mp3',
    videoUrl: 'https://player.vimeo.com/external/559163893.hd.mp4?s=2c517f6f5f15e2b0e7e0c32169b92b34b123c6b6&profile_id=175',
    ageGroup: '7-12 years',
    category: 'Science Fiction',
    readingTime: 6
  },
  {
    id: '4',
    title: 'The Dancing Dragon',
    author: 'Luna Chang',
    coverImage: 'https://images.pexels.com/photos/6044198/pexels-photo-6044198.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    qrCode: 'dancing-dragon-101',
    summary: 'A young dragon learns to embrace her unique dancing style and brings joy to her entire village.',
    content: `In a mountain village where dragons lived among clouds, there was a little dragon named Mei who loved to dance. Unlike other dragons who practiced traditional flying formations, Mei would twirl and spin through the air, creating beautiful patterns with her sparkly scales.

"Dragons don't dance!" the elders would say. "We soar majestically, we glide gracefully, but we do not dance!"

But Mei couldn't help herself. Every morning when the sun painted the clouds pink and gold, she would rise early and practice her dance moves. She would leap from cloud to cloud, performing pirouettes and loop-de-loops that made the morning dew sparkle like diamonds.

One day, as the village prepared for the annual Dragon Festival, dark storm clouds gathered unexpectedly. The festival decorations began to blow away, and the younger dragons were scared of the thunder.

That's when Mei had an idea. She started to dance among the storm clouds, her scales catching what little light remained and reflecting it in beautiful patterns. As she danced, she gathered the clouds together, weaving them into shapes with her movements.

Soon, other young dragons joined her, following her lead. Together, they danced with the storm, turning something scary into something beautiful. The village watched in amazement as the dancing dragons transformed the threatening storm into a magnificent aerial ballet.

From that day forward, the Dragon Festival always included a special dance performance, led by Mei, who had taught everyone that sometimes the most beautiful traditions are the new ones we create ourselves.`,
    audioUrl: 'https://example.com/audio/dancing-dragon.mp3',
    videoUrl: 'https://player.vimeo.com/external/434045526.hd.mp4?s=13e527c546668b3f7c2f8e37c29c8d0b1f7c4c6f&profile_id=175',
    ageGroup: '4-8 years',
    category: 'Fantasy',
    readingTime: 7
  },
  {
    id: '5',
    title: 'The Time-Traveling Telescope',
    author: 'Professor Starlight',
    coverImage: 'https://images.pexels.com/photos/1274260/pexels-photo-1274260.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    qrCode: 'telescope-202',
    summary: 'A young astronomer discovers that her grandmother\'s old telescope can do more than just view stars - it can look into the past!',
    content: `Sarah's grandmother had left her many things, but the old brass telescope was her favorite. It looked ordinary enough, sitting on its wooden tripod by her bedroom window, but Sarah knew it was special.

One night, while studying the stars for her science project, Sarah noticed something strange. When she looked through the telescope at a particular angle, the stars seemed to move backward, like someone rewinding a video.

"That's impossible," she whispered to herself. But as she continued to watch, she realized she wasn't just seeing stars - she was seeing history unfold through the telescope's lens.

She saw dinosaurs roaming ancient plains, pyramids being built block by block, and great sailing ships discovering new continents. Each turn of the telescope's focus ring took her to a different era.

Sarah quickly learned that this amazing gift came with responsibility. Her grandmother had left her a note hidden in the telescope's case: "The past is not just for watching, dear one. It's for learning."

Every night, Sarah would choose a different point in history to study. She watched as civilizations rose and fell, as great inventions were created, and as ordinary people made extraordinary choices that shaped the future.

But her most important discovery came when she pointed the telescope at her own backyard from just a few years ago. There was her grandmother, looking up at the stars through this very same telescope, waving as if she knew Sarah would be watching someday.

That's when Sarah understood - the real magic wasn't in seeing the past, but in understanding how all our stories are connected across time, like stars in a constellation.`,
    audioUrl: 'https://example.com/audio/time-telescope.mp3',
    videoUrl: 'https://player.vimeo.com/external/499537082.hd.mp4?s=f887f31c5f0d75c6d0f5d3f185a4e06f0e499615&profile_id=175',
    ageGroup: '9-12 years',
    category: 'Science Fiction',
    readingTime: 8
  },
  {
    id: '6',
    title: 'The Monkey and the Crocodile',
    author: 'Ancient Wisdom Tales',
    coverImage: 'https://images.pexels.com/photos/1661535/pexels-photo-1661535.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    qrCode: 'monkey-crocodile-303',
    summary: 'A classic tale of friendship, betrayal, and quick thinking as a clever monkey outwits a hungry crocodile.',
    content: `In the heart of a lush jungle, beside a winding river, lived a clever monkey named Manu. Every day, he would swing from branch to branch, gathering the sweetest fruits from the tallest trees. His favorite spot was a magnificent jamun tree that grew right at the water's edge, its branches heavy with purple, juicy fruits.

One sunny morning, as Manu was enjoying his breakfast of jamun fruits, he noticed a crocodile floating lazily in the river below. The crocodile looked tired and hungry.

"Good morning, friend!" called out Manu cheerfully. "You look quite weary. Would you like some of these delicious jamun fruits?"

The crocodile, whose name was Kumbhir, looked up in surprise. No one had ever been kind to him before. "That's very generous of you," he replied. "I would love to try some."

Manu threw down several ripe fruits, and Kumbhir found them to be the most delicious things he had ever tasted. From that day forward, the monkey and the crocodile became the best of friends. Every morning, Manu would share his fruits with Kumbhir, and they would chat about life in the jungle.

As days passed, their friendship grew stronger. Manu would tell funny stories about his adventures in the treetops, while Kumbhir shared tales of the mysterious underwater world. They laughed together, played games, and truly enjoyed each other's company.

However, Kumbhir had a wife who lived in a cave across the river. When she heard about the delicious fruits her husband brought home every day, she became curious about their source.

"These fruits are incredibly sweet," she said one evening. "If the monkey eats such wonderful fruits every day, his heart must be even sweeter. I want to eat the monkey's heart!"

Kumbhir was horrified. "I cannot betray my friend! Manu trusts me completely."

But his wife was persistent and cunning. "If you don't bring me the monkey's heart, I will leave you forever," she threatened. "Besides, it's just one small monkey. Think of how happy you'll make me!"

Torn between his friendship and his wife's demands, Kumbhir reluctantly agreed to the terrible plan. The next morning, he swam to the jamun tree with a heavy heart.

"Good morning, Manu!" he called out, trying to sound cheerful. "I have a wonderful idea. My wife has heard so much about you, and she would love to meet you. Why don't you come to our home for dinner? I can carry you across the river on my back."

Manu was delighted. He had always wondered about Kumbhir's family and was excited to meet his wife. "What a wonderful invitation! I would love to meet her."

Without any suspicion, Manu climbed onto Kumbhir's broad back, and they began swimming across the river. The water was cool and refreshing, and Manu enjoyed the new perspective of the jungle from the middle of the river.

Halfway across, however, Kumbhir's conscience began to trouble him. The weight of his deception became unbearable, and he couldn't keep the secret any longer.

"Manu, my friend," he said sadly, "I must tell you the truth. My wife doesn't really want to meet you for dinner. She wants to eat your heart because she believes it will be sweet like the fruits you eat."

Manu's mind raced. He was in the middle of the river with no way to escape, but he didn't panic. Instead, he used his greatest weapon – his intelligence.

"Oh, Kumbhir!" Manu exclaimed, slapping his forehead dramatically. "Why didn't you tell me this earlier? I would have been happy to give your wife my heart!"

Kumbhir was confused. "You... you would?"

"Of course!" Manu continued. "But there's one small problem. We monkeys don't carry our hearts inside our bodies all the time. It's too dangerous when we're swinging from tree to tree. We keep our hearts safely stored in our homes. Mine is hanging in the jamun tree!"

Kumbhir's eyes widened. "Really? I had no idea!"

"Oh yes," Manu said convincingly. "If you want to give your wife my heart, we'll have to go back to the tree so I can fetch it for her. I left it hanging on the highest branch for safekeeping."

Without thinking twice, Kumbhir turned around and swam back toward the jamun tree. He was actually relieved that he could fulfill his wife's wish without having to harm his friend directly.

As soon as they reached the riverbank, Manu leaped off Kumbhir's back and scrambled up the tree as fast as he could. Once he was safely perched on the highest branch, he looked down at the crocodile.

"Kumbhir, my friend," Manu called out, "I'm very disappointed in you. How could you believe that any creature keeps their heart outside their body? Hearts are what keep us alive – they must always stay inside us!"

Kumbhir realized he had been outwitted. He felt ashamed of his betrayal and his own foolishness.

"I'm sorry, Manu," he said sadly. "I should never have listened to my wife's cruel plan. I should have valued our friendship more than her selfish desires. Can you ever forgive me?"

Manu looked down at his former friend thoughtfully. "Kumbhir, friendship is built on trust, and you broke that trust. However, I understand that you were torn between loyalty to your friend and loyalty to your wife. But remember this lesson: true friendship should never be sacrificed for anyone's selfish desires."

"I've learned my lesson," Kumbhir replied with genuine remorse. "I will never betray a friend again."

From that day forward, Manu continued to live happily in his jamun tree, but he was much more careful about whom he trusted. Kumbhir returned to his wife and told her that he could not and would not harm innocent creatures for her pleasure.

The story spread throughout the jungle, and all the animals learned an important lesson: that intelligence and quick thinking can overcome even the most dangerous situations, and that true friendship should always be treasured and protected.

And so, Manu the monkey continued to enjoy his sweet jamun fruits, wiser and more cautious, but still kind to those who proved themselves worthy of his trust.`,
    audioUrl: 'https://example.com/audio/monkey-crocodile.mp3',
    videoUrl: 'https://player.vimeo.com/external/456789123.hd.mp4?s=abc123def456ghi789jkl012mno345pqr678stu901&profile_id=175',
    ageGroup: '6-12 years',
    category: 'Moral Tales',
    readingTime: 12
  }
];

// Add test QR codes for easy testing
stories.forEach(story => {
  story.qrCode = `test-story-${story.id}`;
});