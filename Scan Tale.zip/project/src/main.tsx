import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import './index.css';
import { StoryProvider } from './contexts/StoryContext';
import { AuthProvider } from './contexts/AuthContext';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <StoryProvider>
          <App />
        </StoryProvider>
      </AuthProvider>
    </BrowserRouter>
  </StrictMode>
);