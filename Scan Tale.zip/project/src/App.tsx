import React from 'react';
import { Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import Welcome from './pages/Welcome';
import ScanPage from './pages/ScanPage';
import StoryDetails from './pages/StoryDetails';
import StoryLibrary from './pages/StoryLibrary';
import StoryReader from './pages/StoryReader';
import StoryWatch from './pages/StoryWatch';
import QRContentViewer from './pages/QRContentViewer';
import About from './pages/About';
import Contact from './pages/Contact';
import Layout from './components/Layout';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/" element={<HomePage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/about" element={<About />} />
      <Route path="/contact" element={<Contact />} />
      
      {/* Protected Routes */}
      <Route path="/welcome" element={
        <ProtectedRoute>
          <Welcome />
        </ProtectedRoute>
      } />
      
      <Route element={
        <ProtectedRoute>
          <Layout />
        </ProtectedRoute>
      }>
        <Route path="/scan" element={<ScanPage />} />
        <Route path="/story/:id" element={<StoryDetails />} />
        <Route path="/library" element={<StoryLibrary />} />
        <Route path="/read/:id" element={<StoryReader />} />
        <Route path="/watch/:id" element={<StoryWatch />} />
        <Route path="/qr-content" element={<QRContentViewer />} />
      </Route>
    </Routes>
  );
}

export default App;