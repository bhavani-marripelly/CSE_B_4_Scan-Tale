export interface Story {
  id: string;
  title: string;
  author: string;
  coverImage: string;
  qrCode: string;
  summary: string;
  content: string;
  audioUrl?: string;
  videoUrl?: string;
  ageGroup: string;
  category: string;
  readingTime: number;
}

export interface ScannedQRCode {
  code: string;
  timestamp: number;
  storyId?: string;
}