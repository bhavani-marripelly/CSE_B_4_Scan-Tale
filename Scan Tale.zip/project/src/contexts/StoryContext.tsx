import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { stories } from '../data/stories';
import { Story, ScannedQRCode } from '../types/Story';

interface StoryContextType {
  stories: Story[];
  currentStory: Story | null;
  setCurrentStory: (story: Story | null) => void;
  findStoryByQRCode: (qrCode: string) => Story | null;
  findStoryById: (id: string) => Story | null;
  scannedCodes: ScannedQRCode[];
  addScannedCode: (code: string, storyId?: string) => void;
}

const StoryContext = createContext<StoryContextType | undefined>(undefined);

const STORAGE_KEY = 'scantale_scanned_codes';

interface StoryProviderProps {
  children: ReactNode;
}

export const StoryProvider = ({ children }: StoryProviderProps) => {
  const [currentStory, setCurrentStory] = useState<Story | null>(null);
  const [scannedCodes, setScannedCodes] = useState<ScannedQRCode[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(scannedCodes));
  }, [scannedCodes]);

  const findStoryByQRCode = (qrCode: string): Story | null => {
    const found = stories.find(story => story.qrCode === qrCode);
    return found || null;
  };

  const findStoryById = (id: string): Story | null => {
    const found = stories.find(story => story.id === id);
    return found || null;
  };

  const addScannedCode = (code: string, storyId?: string) => {
    // Check if this code was already scanned recently (within last 5 minutes)
    const recentScan = scannedCodes.find(scan => 
      scan.code === code && (Date.now() - scan.timestamp) < 5 * 60 * 1000
    );
    
    if (!recentScan) {
      const newScan: ScannedQRCode = {
        code,
        timestamp: Date.now(),
        storyId
      };
      setScannedCodes(prev => [newScan, ...prev.slice(0, 49)]); // Keep only last 50 scans
    }
  };

  return (
    <StoryContext.Provider value={{
      stories,
      currentStory,
      setCurrentStory,
      findStoryByQRCode,
      findStoryById,
      scannedCodes,
      addScannedCode
    }}>
      {children}
    </StoryContext.Provider>
  );
};

export const useStory = (): StoryContextType => {
  const context = useContext(StoryContext);
  if (context === undefined) {
    throw new Error('useStory must be used within a StoryProvider');
  }
  return context;
};